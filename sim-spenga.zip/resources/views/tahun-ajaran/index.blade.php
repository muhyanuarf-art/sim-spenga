@extends('layouts.app')
@section('title', 'Tahun Ajaran')

@section('content')
<div class="space-y-6" x-data="{ showForm: false }">

    {{-- Status ringkas periode aktif — tanpa tombol, tanpa tanggal (poin 1 & 2) --}}
    <div class="card p-5">
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Periode Aktif</p>
        @if(!$periodeAktif)
            <p class="text-sm text-amber-600">Belum ada periode aktif. Aktifkan salah satu Tahun Ajaran di tabel bawah.</p>
        @else
            <p class="text-lg font-bold text-slate-800">
                {{ $periodeAktif->nama }} — Semester {{ $periodeAktif->semester }}
                <span class="badge {{ $periodeAktif->statusBadgeClass() }} ml-1 align-middle">{{ $periodeAktif->statusLabel() }}</span>
            </p>
        @endif
    </div>

    {{-- Buat Tahun Ajaran berikutnya (2 semester sekaligus) kalau belum ada --}}
    @if($namaTahunAjaranBerikutnya && !$tahunAjaranBerikutnyaSudahAda)
    <div class="card p-5">
        <div class="flex flex-wrap items-center justify-between gap-4">
            <p class="text-sm text-slate-600">
                Siapkan Tahun Ajaran <span class="font-bold">{{ $namaTahunAjaranBerikutnya }}</span> (Semester Ganjil & Genap langsung dibuat, status Akan Datang — tidak langsung aktif).
            </p>
            <form method="POST" action="{{ route('tahun-ajaran.buat-baru') }}"
                  onsubmit="return confirm('Buat Tahun Ajaran {{ $namaTahunAjaranBerikutnya }} (Semester Ganjil & Genap)?')">
                @csrf
                <input type="hidden" name="nama" value="{{ $namaTahunAjaranBerikutnya }}">
                <button class="btn-primary whitespace-nowrap">+ Buat Tahun Ajaran {{ $namaTahunAjaranBerikutnya }}</button>
            </form>
        </div>
    </div>
    @endif

    <div class="flex justify-end">
        <button @click="showForm = !showForm" class="btn-primary">+ Tambah Tahun Ajaran</button>
    </div>

    <div class="card p-5" x-show="showForm" x-cloak x-transition>
        <p class="font-bold text-slate-800 mb-4">Tambah Tahun Ajaran</p>
        <form method="POST" action="{{ route('tahun-ajaran.store') }}" class="grid sm:grid-cols-3 gap-3 items-end">
            @csrf
            <input type="text" name="nama" placeholder="Contoh: 2026/2027" required class="input">
            <select name="semester" required class="input">
                <option value="Ganjil">Ganjil</option>
                <option value="Genap">Genap</option>
            </select>
            <button type="submit" class="btn-primary h-[38px]">Simpan</button>
        </form>
    </div>

    <div class="card p-5">
        <div class="overflow-x-auto -mx-5">
            <table class="table-clean w-full">
                <thead><tr><th>Tahun Ajaran</th><th>Semester</th><th>Status</th><th>Kunci</th><th class="th-aksi">Aksi</th></tr></thead>
                @forelse($tahunAjaran as $t)
                <tbody x-data="{ editing: false, salin: false }">
                    <tr x-show="!editing && !salin">
                        <td class="font-semibold">{{ $t->nama }}</td>
                        <td>{{ $t->semester }}</td>
                        <td>
                            <span class="badge {{ $t->statusBadgeClass() }}">{{ $t->statusLabel() }}</span>
                        </td>
                        <td>
                            @if($t->isTerkunci())
                                <span class="badge bg-red-50 text-red-700" title="Ditutup {{ optional($t->terkunci_at)->translatedFormat('d M Y H:i') }} oleh {{ $t->terkunciOleh->name ?? '-' }}"><i class="fa-solid fa-lock mr-1.5"></i> Terkunci</span>
                            @elseif($t->dibuka_at)
                                <span class="badge bg-slate-100 text-slate-500" title="Dibuka kembali {{ $t->dibuka_at->translatedFormat('d M Y H:i') }} oleh {{ $t->dibukaOleh->name ?? '-' }}"><i class="fa-solid fa-lock-open mr-1.5"></i> Terbuka</span>
                            @else
                                <span class="badge bg-slate-100 text-slate-500"><i class="fa-solid fa-lock-open mr-1.5"></i> Terbuka</span>
                            @endif
                        </td>
                        <td class="td-aksi">
                            <div class="action-buttons">
                                @if($semesterHilangPerNama->get($t->nama))
                                <form method="POST" action="{{ route('tahun-ajaran.store') }}">
                                    @csrf
                                    <input type="hidden" name="nama" value="{{ $t->nama }}">
                                    <input type="hidden" name="semester" value="{{ $semesterHilangPerNama[$t->nama] }}">
                                    <button class="btn-chip btn-chip-success">+ Tambah Semester {{ $semesterHilangPerNama[$t->nama] }}</button>
                                </form>
                                @endif
                                <button type="button" @click="salin = true" class="btn-chip btn-chip-edit"><i class="fa-solid fa-clipboard-list mr-1.5"></i> Salin Data</button>
                                <button type="button" @click="editing = true" class="btn-chip btn-chip-edit"><i class="fa-solid fa-pen mr-1.5"></i> Edit</button>
                                @unless($t->is_active)
                                @php
                                    $adaPeriodeAktifLain = $periodeAktif && $periodeAktif->id !== $t->id;
                                    $periodeAktifBelumTerkunci = $adaPeriodeAktifLain && ! $periodeAktif->isTerkunci();
                                @endphp
                                <form method="POST" action="{{ route('tahun-ajaran.aktifkan', $t) }}"
                                    @if($periodeAktifBelumTerkunci)
                                        onsubmit="return confirm('PERHATIAN: {{ $periodeAktif->labelPeriode() }} masih AKTIF dan BELUM DIKUNCI.\nMengaktifkan {{ $t->labelPeriode() }} akan memindahkan status periode aktif sekolah, tapi data {{ $periodeAktif->labelPeriode() }} (jurnal, absensi, jadwal, dll) tetap bisa diubah sampai Anda menutup/menguncinya sendiri lewat tombol \'Tutup Semester\'.\nYakin ingin mengaktifkan {{ $t->labelPeriode() }} sekarang?')"
                                    @else
                                        onsubmit="return confirm('Aktifkan {{ $t->labelPeriode() }} sebagai periode aktif sekolah?')"
                                    @endif
                                >
                                    @csrf
                                    <button class="btn-chip btn-chip-success"><i class="fa-solid fa-circle-check mr-1.5"></i> Aktifkan</button>
                                </form>
                                @endunless
                                @if($t->isTerkunci())
                                    @if(auth()->user()->isAdmin())
                                    <form method="POST" action="{{ route('tahun-ajaran.buka-kunci', $t) }}" onsubmit="return confirm('Semester {{ $t->semester }} ini sudah terkunci.\nMembuka kembali akan memungkinkan perubahan data historis.\nLanjutkan?')">
                                        @csrf
                                        <button class="btn-chip btn-chip-success"><i class="fa-solid fa-lock-open mr-1.5"></i> Buka Kembali</button>
                                    </form>
                                    @endif
                                @else
                                <form method="POST" action="{{ route('tahun-ajaran.kunci', $t) }}" onsubmit="return confirm('Semester {{ $t->semester }} akan ditutup.\nSetelah ditutup, SELURUH data pada semester ini (jurnal, absensi, jadwal, guru mengajar, BK, dst) tidak dapat diubah oleh pengguna biasa — tapi tetap bisa dilihat & dijadikan sumber Salin Data.\nAnda yakin ingin melanjutkan?')">
                                    @csrf
                                    <button class="btn-chip btn-chip-cancel"><i class="fa-solid fa-lock mr-1.5"></i> Tutup Semester</button>
                                </form>
                                @endif
                                @unless($t->isTerkunci())
                                <form method="POST" action="{{ route('tahun-ajaran.destroy', $t) }}" onsubmit="return confirm('Hapus tahun ajaran ini?')">
                                    @csrf @method('DELETE')
                                    <button class="btn-chip btn-chip-delete"><i class="fa-solid fa-trash mr-1.5"></i> Hapus</button>
                                </form>
                                @endunless
                            </div>
                        </td>
                    </tr>

                    {{-- poin 6: Salin Data — pilih tujuan, lalu ke halaman Preview (checklist) sebelum benar-benar menyalin --}}
                    <tr x-show="salin" x-cloak>
                        <td colspan="5" class="bg-brand-50/40">
                            <form method="GET" action="{{ route('tahun-ajaran.duplikasi.preview') }}" class="grid sm:grid-cols-3 gap-3 items-end py-2"
                                  onsubmit="return confirm('Anda akan menyalin data dari {{ $t->nama }} - Semester {{ $t->semester }} ke periode tujuan yang dipilih. Lanjutkan?')">
                                <input type="hidden" name="dari_tahun_ajaran_id" value="{{ $t->id }}">
                                <div class="sm:col-span-2">
                                    <label class="block text-xs font-semibold text-slate-500 mb-1">
                                        Salin Kelas, Wali Kelas, Guru Mengajar, Guru BK & Jadwal dari {{ $t->nama }} - Semester {{ $t->semester }} ke:
                                    </label>
                                    <select name="tahun_ajaran_tujuan" required class="input">
                                        <option value="">Pilih tujuan...</option>
                                        @foreach($tahunAjaran as $tt)
                                            @if($tt->id !== $t->id)
                                            <option value="{{ $tt->id }}">{{ $tt->labelPeriode() }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                                <div class="flex gap-2">
                                    <button type="submit" class="btn-primary h-[38px]">Lihat Preview</button>
                                    <button type="button" @click="salin = false" class="btn-outline h-[38px]">Batal</button>
                                </div>
                            </form>
                        </td>
                    </tr>

                    <tr x-show="editing" x-cloak>
                        <td colspan="5" class="bg-brand-50/40">
                            <form method="POST" action="{{ route('tahun-ajaran.update', $t) }}" class="grid sm:grid-cols-3 gap-3 items-end py-2">
                                @csrf @method('PUT')
                                <input type="text" name="nama" value="{{ $t->nama }}" required class="input">
                                <select name="semester" required class="input">
                                    <option value="Ganjil" {{ $t->semester === 'Ganjil' ? 'selected' : '' }}>Ganjil</option>
                                    <option value="Genap" {{ $t->semester === 'Genap' ? 'selected' : '' }}>Genap</option>
                                </select>
                                @unless($t->is_active)
                                <select name="status" class="input">
                                    <option value="akan_datang" {{ $t->status === 'akan_datang' ? 'selected' : '' }}>Akan Datang</option>
                                    <option value="selesai" {{ $t->status === 'selesai' ? 'selected' : '' }}>Selesai</option>
                                </select>
                                @endunless
                                <div class="flex gap-2">
                                    <button type="submit" class="btn-primary h-[38px]">Simpan</button>
                                    <button type="button" @click="editing = false" class="btn-outline h-[38px]">Batal</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                </tbody>
                @empty
                <tbody>
                    <tr><td colspan="5" class="text-center text-slate-400 py-8">Belum ada data.</td></tr>
                </tbody>
                @endforelse
            </table>
        </div>
    </div>

    {{-- Panduan penggunaan halaman ini — diletakkan di bagian paling bawah,
         tertutup secara default supaya tidak mengganggu admin yang sudah
         terbiasa, tapi selalu ada untuk dibuka kapan saja butuh. --}}
    <div class="card p-5" x-data="{ showBantuan: false }">
        <button type="button" @click="showBantuan = !showBantuan" class="w-full flex items-center justify-between text-left">
            <span class="font-bold text-slate-800"><i class="fa-solid fa-circle-info mr-1.5"></i> Panduan Penggunaan Halaman Tahun Ajaran</span>
            <span class="text-slate-400" x-text="showBantuan ? '▲ Tutup' : '▼ Buka'"></span>
        </button>

        <div x-show="showBantuan" x-cloak x-transition class="mt-5 space-y-6">

            <div>
                <p class="font-semibold text-slate-700 mb-2">Fungsi Setiap Tombol</p>
                <div class="overflow-x-auto -mx-5">
                    <table class="table-clean w-full text-sm">
                        <thead><tr><th>Tombol</th><th>Fungsi</th></tr></thead>
                        <tbody>
                            <tr>
                                <td class="font-semibold whitespace-nowrap">+ Tambah Tahun Ajaran</td>
                                <td>Membuat SATU baris tahun ajaran + semester (misalnya cuma Semester Ganjil saja). Dipakai untuk menambah data secara manual, termasuk melengkapi semester yang kurang.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap">+ Buat Tahun Ajaran [nama]</td>
                                <td>Tombol cepat yang HANYA muncul kalau tahun ajaran berikutnya (dihitung otomatis dari periode aktif) belum ada. Sekali klik langsung membuat Semester Ganjil DAN Genap sekaligus, berstatus Akan Datang.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap">+ Tambah Semester [Ganjil/Genap]</td>
                                <td>Muncul di baris tahun ajaran yang baru punya 1 semester. Klik untuk langsung membuat semester yang masih kurang.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap"><i class="fa-solid fa-pen mr-1.5"></i> Edit</td>
                                <td>Mengubah nama tahun ajaran, semester, atau status (Akan Datang/Selesai) satu baris. Tidak bisa dipakai untuk mengaktifkan — pakai tombol Aktifkan.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap"><i class="fa-solid fa-clipboard-list mr-1.5"></i> Salin Data</td>
                                <td>Menyalin Kelas, Wali Kelas, Guru Mengajar, Guru BK, dan Jadwal dari periode ini ke periode lain yang dipilih. Menampilkan halaman Preview (daftar lengkap apa yang akan disalin) sebelum benar-benar tersimpan.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap"><i class="fa-solid fa-circle-check mr-1.5"></i> Aktifkan</td>
                                <td>Menjadikan semester ini sebagai Periode Aktif sistem. Semester yang tadinya aktif otomatis berhenti aktif (statusnya jadi Selesai). Kalau target beda Tahun Ajaran, sistem akan MENOLAK jika Tahun Ajaran lama belum ditutup penuh.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap"><i class="fa-solid fa-lock mr-1.5"></i> Tutup Semester</td>
                                <td>Mengunci SEMUA data pada semester ini (jurnal, absensi, jadwal, guru mengajar, BK, dst) — tidak bisa diubah pengguna biasa lagi. Data tetap bisa dilihat & tetap bisa dijadikan sumber Salin Data.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap"><i class="fa-solid fa-lock-open mr-1.5"></i> Buka Kembali</td>
                                <td>KHUSUS ADMIN. Membuka kembali semester yang sudah terkunci supaya bisa diedit lagi. Dicatat siapa & kapan yang membuka.</td>
                            </tr>
                            <tr>
                                <td class="font-semibold whitespace-nowrap"><i class="fa-solid fa-trash mr-1.5"></i> Hapus</td>
                                <td>Menghapus baris tahun ajaran/semester. HANYA bisa dilakukan kalau semester itu Terbuka (belum dikunci) DAN belum punya data apa pun — kalau masih ada data terkait, sistem akan menolak dengan pesan jelas.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                <p class="font-semibold text-slate-700 mb-2">Langkah-Langkah: Pergantian Semester (Ganjil → Genap, Tahun Ajaran Sama)</p>
                <ol class="text-sm text-slate-600 list-decimal list-inside space-y-1">
                    <li>Pastikan Semester Genap sudah ada (kalau belum, klik "+ Tambah Semester Genap" di baris Semester Ganjil).</li>
                    <li>(Opsional, kalau Guru Mengajar/Jadwal Semester Genap belum ada dan memang sama dengan Semester Ganjil) Klik "<i class="fa-solid fa-clipboard-list mr-1.5"></i> Salin Data" pada baris Semester Ganjil → pilih tujuan Semester Genap → cek Preview → "Salin Sekarang".</li>
                    <li>Klik "<i class="fa-solid fa-lock mr-1.5"></i> Tutup Semester" pada baris Semester Ganjil → konfirmasi.</li>
                    <li>Klik "<i class="fa-solid fa-circle-check mr-1.5"></i> Aktifkan" pada baris Semester Genap.</li>
                </ol>
                <p class="text-xs text-slate-400 mt-2">
                    Selesai — Semester Genap jadi Periode Aktif. Data baru otomatis masuk ke Semester Genap, data Semester Ganjil tetap tersimpan & bisa dilihat kapan saja.
                </p>
            </div>

            <div>
                <p class="font-semibold text-slate-700 mb-2">Langkah-Langkah: Pergantian Tahun Ajaran (Akhir Tahun)</p>
                <ol class="text-sm text-slate-600 list-decimal list-inside space-y-1">
                    <li>Pastikan Semester Genap tahun ajaran LAMA sudah ditutup: klik "<i class="fa-solid fa-lock mr-1.5"></i> Tutup Semester" pada baris itu (kalau belum).</li>
                    <li>Buat Tahun Ajaran BARU: klik "+ Buat Tahun Ajaran [nama]" (otomatis membuat Semester Ganjil & Genap).</li>
                    <li>Klik "<i class="fa-solid fa-clipboard-list mr-1.5"></i> Salin Data" pada baris Semester GENAP tahun LAMA → pilih tujuan Semester GANJIL tahun BARU → cek halaman Preview (Kelas & Wali Kelas, Guru Mengajar, Guru BK, Jadwal) → "Salin Sekarang".</li>
                    <li>Buka menu Data Kelas (tahun baru) → sesuaikan Wali Kelas kalau ada pergantian.</li>
                    <li>Buka menu Kenaikan Kelas → Tahun Ajaran Asal pilih tahun LAMA → proses kenaikan kelas per kelas.</li>
                    <li>Periksa menu Guru Mengajar & Jadwal untuk tahun baru — lengkapi kalau ada yang masih kurang.</li>
                    <li>Kembali ke halaman ini → klik "<i class="fa-solid fa-circle-check mr-1.5"></i> Aktifkan" pada Semester Ganjil tahun BARU.</li>
                </ol>
                <p class="text-xs text-amber-600 mt-2">
                    <i class="fa-solid fa-triangle-exclamation mr-1.5"></i> Kalau tombol Aktifkan ditolak: masih ada semester (Ganjil atau Genap) tahun lama yang belum di-"Tutup Semester". Tutup dulu semuanya, baru coba Aktifkan lagi.
                </p>
            </div>

            <div>
                <p class="font-semibold text-slate-700 mb-2">Aturan Penting</p>
                <ul class="text-sm text-slate-600 list-disc list-inside space-y-1">
                    <li>Hanya ada SATU periode aktif dalam satu waktu — dijaga otomatis oleh sistem.</li>
                    <li>Data yang sudah Terkunci hanya bisa dilihat, tidak bisa diubah oleh guru/wali kelas/BK.</li>
                    <li>Hanya Admin yang bisa "<i class="fa-solid fa-lock-open mr-1.5"></i> Buka Kembali" semester yang sudah terkunci.</li>
                    <li>Tahun Ajaran baru tidak bisa diaktifkan sebelum Tahun Ajaran lama ditutup penuh (Ganjil & Genap-nya sama-sama terkunci).</li>
                    <li>"<i class="fa-solid fa-clipboard-list mr-1.5"></i> Salin Data" aman dijalankan berulang kali — data yang sudah pernah tersalin tidak akan dobel.</li>
                </ul>
            </div>

        </div>
    </div>
</div>
@endsection
